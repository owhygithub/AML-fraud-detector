$PYTHON -m pip install .
